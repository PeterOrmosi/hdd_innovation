library(biostat3)
library(zoo)
library(gsynth)
library(dplyr)
library(Synth)
require(Rcpp)
require(ggplot2)
require(GGally) 
require(foreach)  
require(doParallel) 
require(abind)
library(panelView)
library(ggpubr)
library(panelView)
library(tidyverse)
library(plm)
library(multcomp)
library(dlnm)
library(foreign)
library(data.table)
library(lmtest)
library(xlsx)
library(lubridate)
library(nlme)
library(glmmML)

completeFun <- function(data, desiredCols) {
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
}

bracket<-function(x){
  x<-paste0('(',x,')')
}

starring<-function(x){
  coef1=round(x[1],3)
  est=ifelse(x[4]<0.01,paste0(coef1,'***'),ifelse((x[4]>=0.01)&(x[4]<0.05),paste0(coef1,'**'),
                                                  ifelse((x[4]>=0.05)&(x[4]<0.1),paste0(coef1,'*'),coef1))) 
  }

starringse<-function(x){
  serr=paste0("(",round(x[2],4),")")
  }

force_bind = function(df1, df2) {
  colnames(df2) = colnames(df1)
  bind_rows(df1, df2)
}


gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA

### without weights but controlling for the covariates


df_char<-read.csv('data_with_weights.csv')

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$panel2<-df_char$panel
df_char$rdint<-df_char$rdint*100
df_char<-pdata.frame(df_char,index=c("panel2","timeq"))  
df_char$pat4 <-lag(df_char$dpat,4)
df_char$rdint4 <-lag(df_char$rdint,4)

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$t<-as.numeric(df_char$timeq)






fnum <- as.formula(paste('number', paste(c('pm','treat','pmtreat','rdint4','rdint4:pmtreat','pat4','pat4:pmtreat','totalrevenue','grossprofit','totalassets','netincome','totaldebt'),
                                         collapse = " + "),sep = " ~ "))

fnumt <- as.formula(paste('number', paste(c('treat','t','treat:t','rdint4','pat4','totalrevenue','grossprofit','totalassets','netincome','totaldebt'),
                                          collapse = " + "),sep = " ~ "))


fcost <- as.formula(paste('lncost', paste(c('pm','treat','pmtreat','rdint4','rdint4:pmtreat','pat4','pat4:pmtreat','totalrevenue','grossprofit','totalassets','netincome','totaldebt'),
                                          collapse = " + "),sep = " ~ "))

fcostt <- as.formula(paste('lncost', paste(c('treat','t','treat:t','rdint4','pat4','totalrevenue','grossprofit','totalassets','netincome','totaldebt'),
                                           collapse = " + "),sep = " ~ "))


tlist<-c("2013 Q2",'2014 Q2') #,"2014 Q2")

for (i in 1:length(tlist)){
  df<-df_char[(df_char$timeq>='2010 Q2')&(df_char$timeq<='2016 Q3'),]
  df_par<-df_char[(df_char$timeq>="2010 Q2")&(df_char$timeq<as.yearqtr(tlist[i])),]
  df$pm<-as.numeric(ifelse(df$timeq>=as.yearqtr(tlist[i]),1,0))
  df$treat<-ifelse(df$panel>2000,1,0)
  df_par$treat<-ifelse(df_par$panel>2000,1,0)
  
  df$pmtreat<-as.numeric(df$pm * df$treat)
  df <- df %>% filter((panel<2000)|(panel==2001)) 
  df_par <- df_par %>% filter((panel<2000)|(panel==2001)) 
  
  
  reg<-plm(fnum,data = df,  index = c("brand", "timeq"), model = "within", effect='individual')
  regt<-plm(fnumt,data = df_par, index = c("brand", "timeq"), model = "within", effect='individual')
  reg2<-plm(fcost,data = df, index = c("brand", "timeq"), model = "within", effect='individual')
  regt2<-plm(fcostt, data = df_par, index = c("brand", "timeq"), model = "within", effect='individual')
  coef<-coeftest(reg) #,vcov=vcovHC(reg,type="HC0"))
  coeft<-coeftest(regt)
  coef2<-coeftest(reg2) #,vcov=vcovHC(reg,type="HC0"))
  coeft2<-coeftest(regt2)
  
  table1<-(as.data.frame(apply(coef,1,starring)))
  table2<-(as.data.frame(apply(coef,1,starringse)))
  table3<-(as.data.frame(apply(coef2,1,starring)))
  table4<-(as.data.frame(apply(coef2,1,starringse)))
  tablen=cbind(table1,table2)
  tablec=cbind(table3,table4)
  tablen <-as.data.frame( do.call(rbind, lapply(1:nrow(tablen), function(x) t(tablen[x,]))))
  tablec <-as.data.frame( do.call(rbind, lapply(1:nrow(tablec), function(x) t(tablec[x,]))))
  sizen=as.data.frame(as.factor(nobs(reg)))
  sizec=as.data.frame(as.factor(nobs(reg2)))
  colnames(sizen)=colnames(tablen)
  colnames(sizec)=colnames(tablec)
  parn<-as.data.frame(as.factor(round(coeft[9,4],4)))
  parc<-as.data.frame(as.factor(round(coeft2[9,4],4)))
  colnames(parn)=colnames(tablen)
  colnames(parc)=colnames(tablec)
  tablen<-rbind(tablen,parn,sizen)
  tablec<-rbind(tablec,parc,sizec)
  table<-cbind(tablen,tablec)
  names(table)<-c('numbers','cost')
  table<-table[c(1,2,3,4,5,6,7,8,19,20,21,22,23,24),]
  row.names(table)<-c('Post-merger','1','Treatment effect','3','R&D','4','Patent count','5','R&D x treatment effect','6','Patent x treatment effect','7','p_val parallel trend','N')
  assign(paste0('sg',i),table)
  
  rdint4nprec<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4npret<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4npostc<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4npostt<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4did<-(rdint4npostt-rdint4npret) - (rdint4npostc-rdint4nprec)
  rdint4cprec<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4cpret<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4cpostc<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4cpostt<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4cdid<-(rdint4cpostt-rdint4cpret) - (rdint4cpostc-rdint4cprec)
  
  pat4nprec<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4npret<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4npostc<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4npostt<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4did<-(pat4npostt-pat4npret) - (pat4npostc-pat4nprec)
  pat4cprec<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4cpret<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4cpostc<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4cpostt<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4cdid<-(pat4cpostt-pat4cpret) - (pat4cpostc-pat4cprec)
  
  lc1n<-as.data.frame(svycontrast(reg, c("rdint4" = rdint4did,"pmtreat" = 1, "pmtreat:rdint4"=rdint4npostt)))
  lc1n[1,3]<-as.numeric(lc1n[1,1])/as.numeric(lc1n[1,2])
  lc1n[1,4]=2*pnorm(-abs(lc1n[1,3]))
  lc2n<-as.data.frame(svycontrast(reg, c("rdint4" = rdint4did)))
  lc2n[1,3]<-as.numeric(lc2n[1,1])/as.numeric(lc2n[1,2])
  lc2n[1,4]=2*pnorm(-abs(lc2n[1,3]))
  lc3n<-as.data.frame(svycontrast(reg, c("pmtreat" = 1, "pmtreat:rdint4"=rdint4npostt)))
  lc3n[1,3]<-as.numeric(lc3n[1,1])/as.numeric(lc3n[1,2])
  lc3n[1,4]=2*pnorm(-abs(lc3n[1,3]))
  lcn<-rbind(lc1n,lc2n,lc3n)
  
  lc1c<-as.data.frame(svycontrast(reg2, c("rdint4" = rdint4cdid,"pmtreat" = 1, "pmtreat:rdint4"=rdint4cpostt)))
  lc1c[1,3]<-as.numeric(lc1c[1,1])/as.numeric(lc1c[1,2])
  lc1c[1,4]=2*pnorm(-abs(lc1c[1,3]))
  lc2c<-as.data.frame(svycontrast(reg2, c("rdint4" = rdint4cdid)))
  lc2c[1,3]<-as.numeric(lc2c[1,1])/as.numeric(lc2c[1,2])
  lc2c[1,4]=2*pnorm(-abs(lc2c[1,3]))
  lc3c<-as.data.frame(svycontrast(reg2, c("pmtreat" = 1, "pmtreat:rdint4"=rdint4cpostt)))
  lc3c[1,3]<-as.numeric(lc3c[1,1])/as.numeric(lc3c[1,2])
  lc3c[1,4]=2*pnorm(-abs(lc3c[1,3]))
  lcc<-rbind(lc1c,lc2c,lc3c)
  
  lc1np<-as.data.frame(svycontrast(reg, c("pat4" = pat4did,"pmtreat" = 1, "pmtreat:pat4"=pat4npostt)))
  lc1np[1,3]<-as.numeric(lc1np[1,1])/as.numeric(lc1np[1,2])
  lc1np[1,4]=2*pnorm(-abs(lc1np[1,3]))
  lc2np<-as.data.frame(svycontrast(reg, c("pat4" = pat4did)))
  lc2np[1,3]<-as.numeric(lc2np[1,1])/as.numeric(lc2np[1,2])
  lc2np[1,4]=2*pnorm(-abs(lc2np[1,3]))
  lc3np<-as.data.frame(svycontrast(reg, c("pmtreat" = 1, "pmtreat:pat4"=pat4npostt)))
  lc3np[1,3]<-as.numeric(lc3np[1,1])/as.numeric(lc3np[1,2])
  lc3np[1,4]=2*pnorm(-abs(lc3np[1,3]))
  lcnp<-rbind(lc1np,lc2np,lc3np)
  
  lc1cp<-as.data.frame(svycontrast(reg2, c("pat4" = pat4cdid,"pmtreat" = 1, "pmtreat:pat4"=pat4cpostt)))
  lc1cp[1,3]<-as.numeric(lc1cp[1,1])/as.numeric(lc1cp[1,2])
  lc1cp[1,4]=2*pnorm(-abs(lc1cp[1,3]))
  lc2cp<-as.data.frame(svycontrast(reg2, c("pat4" = pat4cdid)))
  lc2cp[1,3]<-as.numeric(lc2cp[1,1])/as.numeric(lc2c[1,2])
  lc2cp[1,4]=2*pnorm(-abs(lc2cp[1,3]))
  lc3cp<-as.data.frame(svycontrast(reg2, c("pmtreat" = 1, "pmtreat:pat4"=pat4cpostt)))
  lc3cp[1,3]<-as.numeric(lc3cp[1,1])/as.numeric(lc3cp[1,2])
  lc3cp[1,4]=2*pnorm(-abs(lc3cp[1,3]))
  lccp<-rbind(lc1cp,lc2cp,lc3cp)
  
  lcn<-rbind(lcn,lcnp)
  lcc<-rbind(lcc,lccp)
  
  table1n<-(as.data.frame(apply(lcn,1,starring)))
  table2n<-(as.data.frame(apply(lcn,1,starringse)))
  tablen=cbind(table1n,table2n)
  table1c<-(as.data.frame(apply(lcc,1,starring)))
  table2c<-(as.data.frame(apply(lcc,1,starringse)))
  tablec=cbind(table1c,table2c)
  
  tablen <-as.data.frame( do.call(rbind, lapply(1:nrow(tablen), function(x) t(tablen[x,]))))
  tablec <-as.data.frame( do.call(rbind, lapply(1:nrow(tablec), function(x) t(tablec[x,]))))
  table<-cbind(tablen,tablec)
  row.names(table)<-c('Joint R&D effect','0','R&D increase','1','Productivity','2','Joint patent effect','3','Patent increase','4','Patent productivity','5')
  assign(paste0('sglc',i),table)
  
  }

sg_1<-cbind(sg1,sg2)
sg_2<-cbind(sglc1,sglc2)
names(sg_1)<-c('num2013sg','cost2013sg','num2014sg','cost2014sg')
names(sg_2)<-c('num2013sg','cost2013sg','num2014sg','cost2014sg')
sg<-rbind(sg_1,sg_2)




# WD

for (i in 1:length(tlist)){
  df<-df_char[(df_char$timeq>='2010 Q2')&(df_char$timeq<='2016 Q3'),]
  df_par<-df_char[(df_char$timeq>="2010 Q2")&(df_char$timeq<as.yearqtr(tlist[i])),]
  df$pm<-as.numeric(ifelse(df$timeq>=as.yearqtr(tlist[i]),1,0))
  df$treat<-ifelse(df$panel>2000,1,0)
  df_par$treat<-ifelse(df_par$panel>2000,1,0)
  
  df$pmtreat<-as.numeric(df$pm * df$treat)
  df <- df %>% filter((panel<2000)|(panel==2002)) 
  df_par <- df_par %>% filter((panel<2000)|(panel==2002)) 
  
  
  reg<-plm(fnum,data = df,  index = c("brand", "timeq"), model = "within", effect='individual')
  regt<-plm(fnumt,data = df_par, index = c("brand", "timeq"), model = "within", effect='individual')
  reg2<-plm(fcost,data = df, index = c("brand", "timeq"), model = "within", effect='individual')
  regt2<-plm(fcostt, data = df_par, index = c("brand", "timeq"), model = "within", effect='individual')
  coef<-coeftest(reg) #,vcov=vcovHC(reg,type="HC0"))
  coeft<-coeftest(regt)
  coef2<-coeftest(reg2) #,vcov=vcovHC(reg,type="HC0"))
  coeft2<-coeftest(regt2)
  
  table1<-(as.data.frame(apply(coef,1,starring)))
  table2<-(as.data.frame(apply(coef,1,starringse)))
  table3<-(as.data.frame(apply(coef2,1,starring)))
  table4<-(as.data.frame(apply(coef2,1,starringse)))
  tablen=cbind(table1,table2)
  tablec=cbind(table3,table4)
  tablen <-as.data.frame( do.call(rbind, lapply(1:nrow(tablen), function(x) t(tablen[x,]))))
  tablec <-as.data.frame( do.call(rbind, lapply(1:nrow(tablec), function(x) t(tablec[x,]))))
  sizen=as.data.frame(as.factor(nobs(reg)))
  sizec=as.data.frame(as.factor(nobs(reg2)))
  colnames(sizen)=colnames(tablen)
  colnames(sizec)=colnames(tablec)
  parn<-as.data.frame(as.factor(round(coeft[9,4],4)))
  parc<-as.data.frame(as.factor(round(coeft2[9,4],4)))
  colnames(parn)=colnames(tablen)
  colnames(parc)=colnames(tablec)
  tablen<-rbind(tablen,parn,sizen)
  tablec<-rbind(tablec,parc,sizec)
  table<-cbind(tablen,tablec)
  names(table)<-c('numbers','cost')
  table<-table[c(1,2,3,4,5,6,7,8,19,20,21,22,23,24),]
  row.names(table)<-c('Post-merger','1','Treatment effect','3','R&D','4','Patent count','5','R&D x treatment effect','6','Patent x treatment effect','7','p_val parallel trend','N')
  assign(paste0('wd',i),table)
  
  rdint4nprec<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4npret<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4npostc<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4npostt<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4did<-(rdint4npostt-rdint4npret) - (rdint4npostc-rdint4nprec)
  rdint4cprec<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4cpret<-mean(df$rdint4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4cpostc<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  rdint4cpostt<-mean(df$rdint4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  rdint4cdid<-(rdint4cpostt-rdint4cpret) - (rdint4cpostc-rdint4cprec)
  
  pat4nprec<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4npret<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4npostc<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4npostt<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4did<-(pat4npostt-pat4npret) - (pat4npostc-pat4nprec)
  pat4cprec<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4cpret<-mean(df$pat4[(df$timeq<tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4cpostc<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==0)],na.rm=TRUE)
  pat4cpostt<-mean(df$pat4[(df$timeq>=tlist[i])&(df$treat==1)],na.rm=TRUE)
  pat4cdid<-(pat4cpostt-pat4cpret) - (pat4cpostc-pat4cprec)
  
  lc1n<-as.data.frame(svycontrast(reg, c("rdint4" = rdint4did,"pmtreat" = 1, "pmtreat:rdint4"=rdint4npostt)))
  lc1n[1,3]<-as.numeric(lc1n[1,1])/as.numeric(lc1n[1,2])
  lc1n[1,4]=2*pnorm(-abs(lc1n[1,3]))
  lc2n<-as.data.frame(svycontrast(reg, c("rdint4" = rdint4did)))
  lc2n[1,3]<-as.numeric(lc2n[1,1])/as.numeric(lc2n[1,2])
  lc2n[1,4]=2*pnorm(-abs(lc2n[1,3]))
  lc3n<-as.data.frame(svycontrast(reg, c("pmtreat" = 1, "pmtreat:rdint4"=rdint4npostt)))
  lc3n[1,3]<-as.numeric(lc3n[1,1])/as.numeric(lc3n[1,2])
  lc3n[1,4]=2*pnorm(-abs(lc3n[1,3]))
  lcn<-rbind(lc1n,lc2n,lc3n)
  
  lc1c<-as.data.frame(svycontrast(reg2, c("rdint4" = rdint4cdid,"pmtreat" = 1, "pmtreat:rdint4"=rdint4cpostt)))
  lc1c[1,3]<-as.numeric(lc1c[1,1])/as.numeric(lc1c[1,2])
  lc1c[1,4]=2*pnorm(-abs(lc1c[1,3]))
  lc2c<-as.data.frame(svycontrast(reg2, c("rdint4" = rdint4cdid)))
  lc2c[1,3]<-as.numeric(lc2c[1,1])/as.numeric(lc2c[1,2])
  lc2c[1,4]=2*pnorm(-abs(lc2c[1,3]))
  lc3c<-as.data.frame(svycontrast(reg2, c("pmtreat" = 1, "pmtreat:rdint4"=rdint4cpostt)))
  lc3c[1,3]<-as.numeric(lc3c[1,1])/as.numeric(lc3c[1,2])
  lc3c[1,4]=2*pnorm(-abs(lc3c[1,3]))
  lcc<-rbind(lc1c,lc2c,lc3c)
  
  lc1np<-as.data.frame(svycontrast(reg, c("pat4" = pat4did,"pmtreat" = 1, "pmtreat:pat4"=pat4npostt)))
  lc1np[1,3]<-as.numeric(lc1np[1,1])/as.numeric(lc1np[1,2])
  lc1np[1,4]=2*pnorm(-abs(lc1np[1,3]))
  lc2np<-as.data.frame(svycontrast(reg, c("pat4" = pat4did)))
  lc2np[1,3]<-as.numeric(lc2np[1,1])/as.numeric(lc2np[1,2])
  lc2np[1,4]=2*pnorm(-abs(lc2np[1,3]))
  lc3np<-as.data.frame(svycontrast(reg, c("pmtreat" = 1, "pmtreat:pat4"=pat4npostt)))
  lc3np[1,3]<-as.numeric(lc3np[1,1])/as.numeric(lc3np[1,2])
  lc3np[1,4]=2*pnorm(-abs(lc3np[1,3]))
  lcnp<-rbind(lc1np,lc2np,lc3np)
  
  lc1cp<-as.data.frame(svycontrast(reg2, c("pat4" = pat4cdid,"pmtreat" = 1, "pmtreat:pat4"=pat4cpostt)))
  lc1cp[1,3]<-as.numeric(lc1cp[1,1])/as.numeric(lc1cp[1,2])
  lc1cp[1,4]=2*pnorm(-abs(lc1cp[1,3]))
  lc2cp<-as.data.frame(svycontrast(reg2, c("pat4" = pat4cdid)))
  lc2cp[1,3]<-as.numeric(lc2cp[1,1])/as.numeric(lc2c[1,2])
  lc2cp[1,4]=2*pnorm(-abs(lc2cp[1,3]))
  lc3cp<-as.data.frame(svycontrast(reg2, c("pmtreat" = 1, "pmtreat:pat4"=pat4cpostt)))
  lc3cp[1,3]<-as.numeric(lc3cp[1,1])/as.numeric(lc3cp[1,2])
  lc3cp[1,4]=2*pnorm(-abs(lc3cp[1,3]))
  lccp<-rbind(lc1cp,lc2cp,lc3cp)
  
  lcn<-rbind(lcn,lcnp)
  lcc<-rbind(lcc,lccp)
  
  table1n<-(as.data.frame(apply(lcn,1,starring)))
  table2n<-(as.data.frame(apply(lcn,1,starringse)))
  tablen=cbind(table1n,table2n)
  table1c<-(as.data.frame(apply(lcc,1,starring)))
  table2c<-(as.data.frame(apply(lcc,1,starringse)))
  tablec=cbind(table1c,table2c)
  
  tablen <-as.data.frame( do.call(rbind, lapply(1:nrow(tablen), function(x) t(tablen[x,]))))
  tablec <-as.data.frame( do.call(rbind, lapply(1:nrow(tablec), function(x) t(tablec[x,]))))
  table<-cbind(tablen,tablec)
  row.names(table)<-c('Joint R&D effect','0','R&D increase','1','Productivity','2','Joint patent effect','3','Patent increase','4','Patent productivity','5')
  assign(paste0('wdlc',i),table)
  
}
wd_1<-cbind(wd1,wd2)
wd_2<-cbind(wdlc1,wdlc2)
names(wd_1)<-c('num2013wd','cost2013wd','num2014wd','cost2014wd')
names(wd_2)<-c('num2013wd','cost2013wd','num2014wd','cost2014wd')
wd<-rbind(wd_1,wd_2)


results1<-cbind(sg,wd)
write.xlsx(results1,'results_plm_noweight_both.xlsx')








