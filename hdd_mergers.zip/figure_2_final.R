# code to get all synth results in Table3

library(zoo)
library(gsynth)
library(dplyr)
library(Synth)
require(Rcpp)
require(ggplot2)
require(GGally) 
require(foreach)  
require(doParallel) 
require(abind)
library(panelView)
library(ggpubr)
library(panelView)
library(tidyverse)
library(ggplot2)
library(reshape2)
library(zoo)
library(lubridate)

# here's a function to generate moving averages

fnrollmean <- function (x) {
  if (length(x) < 7) {
    rep(NA,length(x)) 
  } else {
    rollmean(x,3,align="center",na.pad=TRUE)
  }
}

# function to drop panels with missing observations

completeFun <- function(data, desiredCols) {
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
}

## RDINT

My_Theme = theme(
  axis.title.x = element_text(size = 18),
  axis.text.x = element_text(size = 12),
  axis.title.y = element_text(size = 16),
  axis.text.y = element_text(size = 12))




setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA

df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

## getting the control firms - take all firms where there's patent data, and then keep where full coverage of R&D data - should leave 42 + 3 firms

df_nomiss<-completeFun(df_char,c('rdint','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))

counts <- data.frame(table(df_nomiss$panel))
nonmissing<-counts[counts$Freq>=37,]
df_char <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]


theme_set(theme_bw())

#####


df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2006 Q2')&(df_char$timeq<='2016 Q3'),]
df_char$treat<-ifelse(df_char$panel>2000,1,0)
df_char$num_cum<-as.numeric(ave(df_char$number, df_char$panel, FUN=cumsum))
df_char$lncost<-log(df_char$cost)
df_char$cat<-ifelse(df_char$panel==2001,1,ifelse(df_char$panel==2002,2,ifelse(df_char$panel==2003,3,NA)))
df_char$cat2<-ifelse(df_char$panel==2001,1,ifelse(df_char$panel==2002,2,ifelse(df_char$panel==2003,NA,NA)))

# R&D 

theme_set(theme_bw(base_size = 20)) 

aggtab_rd<-aggregate(list(rd=df_char$rdint),by=list(panel=df_char$cat2, time=df_char$timeq),mean,na.rm=T)
aggtab_rd$panel<-as.factor(aggtab_rd$panel)
levels(aggtab_rd$panel) <- c("SG+SAM",'WD+HI')
aggtab_rd$time<-as.yearqtr(aggtab_rd$time)


rd1<-ggplot(aggtab_rd, aes(time)) + 
  geom_line(aes(y = rd, colour = panel),size=1.5, show.legend = TRUE) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) + ylab('Mean R&D intensity (%)') + xlab('Time') + scale_y_continuous(breaks=c(6,8,10,12,14)) +
  geom_vline(xintercept = 2012.25, linetype=4)  + theme(legend.title = element_blank(),
                                                        axis.title=element_text(size=16)) +
  scale_color_grey(start = 0, end = .6) +
  ggtitle('R&D intensity') + theme(plot.title = element_text(hjust = 0.6)) + My_Theme
ggsave('rd1.png')

## Patent

aggtab_pat<-aggregate(list(pat=df_char$dpat),by=list(panel=df_char$cat, time=df_char$timeq),sum,na.rm=T)
aggtab_pat$panel<-as.factor(aggtab_pat$panel)
levels(aggtab_pat$panel) <- c("SG+SAM",'WD+HI','TO+HI')
aggtab_pat$time<-as.yearqtr(aggtab_pat$time)
aggtab_pat <- aggtab_pat %>% group_by(panel) %>% 
  mutate(rollavg=fnrollmean(pat))
aggtab_pat$rollavg<-ifelse(aggtab_pat$panel=="Control",aggtab_pat$rollavg/2,aggtab_pat$rollavg)

pat1<-ggplot(aggtab_pat, aes(time)) + 
  geom_line(aes(y = rollavg, colour = panel),size=1.5)   +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) + ylab('Treatment patent count (3-yr moving average)') + xlab('Time') +  
  geom_vline(xintercept = 2012.25, linetype=4) + scale_color_grey(start = 0, end = .8) + theme(legend.title = element_blank(),
                                                                                               axis.title=element_text(size=16)) +
  ggtitle('Number of new patents') + theme(plot.title = element_text(hjust = 0.6)) + My_Theme
ggsave('pat1.png')


## numbers

df_char2<-df_char[(df_char$timeq>='2009 Q1')&(df_char$timeq<='2016 Q2'),]


aggtab_num<-aggregate(list(num=df_char2$number),by=list(panel=df_char2$cat, time=df_char2$timeq),sum,na.rm=T)
aggtab_num$panel<-as.factor(aggtab_num$panel)
levels(aggtab_num$panel) <- c("SG+SAM",'WD+HI','TO+HI')
aggtab_num$time<-as.yearqtr(aggtab_num$time)
aggtab_num <- aggtab_num %>% group_by(panel) %>% 
  mutate(rollavg=fnrollmean(num))

num1<-ggplot(aggtab_num, aes(time)) + 
  geom_line(aes(y = rollavg, colour = panel),size=1.5) +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 10)) + ylab('Number of new models (3-yr moving average)') + xlab('Time') +
  geom_vline(xintercept = 2012.25, linetype=4) + scale_color_grey(start = 0, end = .8) + theme(legend.title = element_blank(),
                                                                                               axis.title=element_text(size=16)) + 
  ggtitle('Number of new models') + theme(plot.title = element_text(hjust = 0.6)) + My_Theme
ggsave('num1.png')

### cost

aggtab_cost<-aggregate(list(cost=df_char2$lncost),by=list(panel=df_char2$cat, time=df_char2$timeq),mean,na.rm=T)
aggtab_cost$panel<-as.factor(aggtab_cost$panel)
levels(aggtab_cost$panel) <- c("SG+SAM",'WD+HI','TO+HI')
aggtab_cost$time<-as.yearqtr(aggtab_cost$time)
aggtab_cost$year<-year(aggtab_cost$time)
aggtab_cost <- aggtab_cost %>% group_by(panel) %>% 
  mutate(rollavg=fnrollmean(cost))
aggtab_cost<-aggtab_cost[(aggtab_cost$year>2008),]
aggtab_cost$rollavg<-ifelse(aggtab_cost$panel=="Control",aggtab_cost$rollavg-2,aggtab_cost$rollavg) 


cost1<-ggplot(aggtab_cost, aes(time)) + 
  geom_line(aes(y = rollavg, colour = panel),size=1.5)  +
  scale_x_continuous(breaks = scales::pretty_breaks(n = 8)) + ylab('Unit price ln($/Gb) (3-yr moving average)') +  
  xlab('Time') +
  geom_vline(xintercept = 2012.25, linetype=4) + scale_color_grey(start = 0, end = .8) + theme(legend.title = element_blank(),
                                                                                               axis.title=element_text(size=16)) +
  ggtitle('Unit price (log)') + theme(plot.title = element_text(hjust = 0.6)) + My_Theme

ggsave('cost1.png')

figure<-ggarrange(rd1,num1,pat1,cost1, ncol = 2, nrow = 2,common.legend = TRUE, legend="bottom") 


ggsave('descriptive.pdf',plot=figure,dpi = 700,scale=2)


