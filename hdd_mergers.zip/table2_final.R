# code to get all synth results in Table3

library(zoo)
library(gsynth)
library(dplyr)
library(Synth)
require(Rcpp)
require(ggplot2)
require(GGally) 
require(foreach)  
require(doParallel) 
require(abind)
library(panelView)
library(ggpubr)
library(panelView)
library(tidyverse)


completeFun <- function(data, desiredCols) {
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
}

## RDINT

gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2006 Q4')&(df_char$timeq<='2016 Q2'),]
#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]

treatlist<-c(2001,2002,2003)
tlist<-c('2012 Q2','2013 Q2','2014 Q2')

for (i in treatlist){
  count=1
  for (t in tlist){
    
    df_nomiss<-completeFun(df_char,c('rdint','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))
    
    counts <- data.frame(table(df_nomiss$panel))
    nonmissing<-counts[counts$Freq>=37,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    
    df_synth <- df_synth %>% filter((panel<2000)|(panel==i)) # selecting Seagate
    
    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(rdint ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(rdint~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt, data = df_synth,
                      index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                      inference = "parametric", r = c(0, 5), CV = TRUE, 
                      force = "unit", nboots = 1000, seed = 1111, parallel = TRUE)
    
      
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                     ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('rdatt',i,count),att)
    assign(paste0('rdse',i,count),se)
    control=as.integer(model$Nco)
    assign(paste0('rdcontrol',i,count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('rdmspe',i,count),mspe)
    
    count=count+1
  }
}


### DPAT

gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2006 Q4')&(df_char$timeq<='2016 Q2'),]
#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]

treatlist<-c(2001,2002,2003)
tlist<-c('2012 Q2','2013 Q2','2014 Q2')

for (i in treatlist){
  count=1
  for (t in tlist){
    
    df_nomiss<-completeFun(df_char,c('dpat','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))
    
    counts <- data.frame(table(df_nomiss$panel))
    #nonmissing<-counts[counts$Freq>=37,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    
    df_synth <- df_synth %>% filter((panel<2000)|(panel==i)) # selecting Seagate
    
    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(dpat ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(dpat~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt, data = df_synth,
                    index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                    inference = "parametric", r = c(0, 5), CV = TRUE, 
                    force = "unit", nboots = 1000, seed = 1111, parallel = TRUE)
    
    
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                          ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('patatt',i,count),att)
    assign(paste0('patse',i,count),se)
    control=as.integer(model$Nco)
    assign(paste0('patcontrol',i,count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('patmspe',i,count),mspe)
    
    count=count+1
  }
}



### NUMBER


gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char<-df_char[!is.na(df_char$brand),]
df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2008 Q4')&(df_char$timeq<='2016 Q3'),]
#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]

treatlist<-c(2001,2002,2003)
tlist<-c('2012 Q2','2013 Q2','2014 Q2')

for (i in treatlist){
  count=1
  for (t in tlist){
    
    df_nomiss<-completeFun(df_char,c('number','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses','rdint','dpat'))
    
    counts <- data.frame(table(df_nomiss$panel))
    nonmissing<-counts[counts$Freq>=18,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    
    df_synth <- df_synth %>% filter((panel<2000)|(panel==i)) # selecting Seagate
    
    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(number ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(number~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt+rdint+dpat, data = df_synth,
                    index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                    inference = "parametric", r = c(0, 5), CV = TRUE, 
                    force = "unit", nboots = 1000, seed = 1234, parallel = TRUE)
    
    
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                          ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('numatt',i,count),att)
    assign(paste0('numse',i,count),se)
    control=as.integer(model$Nco)
    assign(paste0('numcontrol',i,count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('nummspe',i,count),mspe)
    
    count=count+1
  }
}


## COST



gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char<-df_char[!is.na(df_char$brand),]
df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2008 Q4')&(df_char$timeq<='2016 Q3'),]
df_char$lncost<-log(df_char$cost)

treatlist<-c(2001,2002,2003)
tlist<-c('2012 Q2','2013 Q2','2014 Q2')

for (i in treatlist){
  count=1
  for (t in tlist){
    
    df_nomiss<-completeFun(df_char,c('lncost','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses','rdint','dpat'))
    
    counts <- data.frame(table(df_nomiss$panel))
    nonmissing<-counts[counts$Freq>=18,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    
    df_synth <- df_synth %>% filter((panel<2000)|(panel==i)) # selecting Seagate
    
    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(lncost ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(lncost~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt+rdint+dpat, data = df_synth,
                    index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                    inference = "parametric", r = c(0, 5), CV = TRUE, 
                    force = "unit", nboots = 1000, seed = 1111, parallel = TRUE)
    
    
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                          ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('costatt',i,count),att)
    assign(paste0('costse',i,count),se)
    control=as.integer(model$Nco)
    assign(paste0('costcontrol',i,count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('costmspe',i,count),mspe)
    
    count=count+1
  }
}






# POOLED
## RD

gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2006 Q4')&(df_char$timeq<='2016 Q2'),]
#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]

count=1 
tlist<-c('2012 Q2','2013 Q2','2014 Q2')
  for (t in tlist){
    
    df_nomiss<-completeFun(df_char,c('rdint','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))
    
    counts <- data.frame(table(df_nomiss$panel))
    nonmissing<-counts[counts$Freq>=37,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    df_synth <- df_synth %>% filter((panel<2000)|(panel==2001)|(panel==2002)) # selecting Seagate
    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse((df_synth$panel>2000),1,0) # excluding Toshiba
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(rdint ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(rdint~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt, data = df_synth,
                    index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                    inference = "parametric", r = c(0, 5), CV = TRUE, 
                    force = "unit", nboots = 1000, seed = 1111, parallel = TRUE)
    
    
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                          ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('prdatt',count),att)
    assign(paste0('prdse',count),se)
    control=as.integer(model$Nco)
    assign(paste0('prdcontrol',count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('prdmspe',count),mspe)
    
    count=count+1
  }


### DPAT

gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2006 Q4')&(df_char$timeq<='2016 Q2'),]
#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]

tlist<-c('2012 Q2','2013 Q2','2014 Q2')
count=1  
  for (t in tlist){
    df_nomiss<-completeFun(df_char,c('dpat','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))
    
    counts <- data.frame(table(df_nomiss$panel))
    #nonmissing<-counts[counts$Freq>=37,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    

    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(dpat ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(dpat~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt, data = df_synth,
                    index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                    inference = "parametric", r = c(0, 5), CV = TRUE, 
                    force = "unit", nboots = 1000, seed = 1111, parallel = TRUE)
    
    
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                          ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('ppatatt',count),att)
    assign(paste0('ppatse',count),se)
    control=as.integer(model$Nco)
    assign(paste0('ppatcontrol',count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('ppatmspe',count),mspe)
    
    count=count+1
  }



### NUMBER


gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char<-df_char[!is.na(df_char$brand),]
df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2008 Q4')&(df_char$timeq<='2016 Q3'),]
#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]


tlist<-c('2012 Q2','2013 Q2','2014 Q2')
count=1   
  for (t in tlist){
 
    df_nomiss<-completeFun(df_char,c('number','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses','rdint','dpat'))
    
    counts <- data.frame(table(df_nomiss$panel))
    nonmissing<-counts[counts$Freq>=18,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    
    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(number ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(number~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt+rdint+dpat, data = df_synth,
                    index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                    inference = "parametric", r = c(0, 5), CV = TRUE, 
                    force = "unit", nboots = 1000, seed = 1111, parallel = TRUE)
    
    
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                          ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('pnumatt',count),att)
    assign(paste0('pnumse',count),se)
    control=as.integer(model$Nco)
    assign(paste0('pnumcontrol',count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('pnummspe',count),mspe)
    
    count=count+1
  }



## COST



gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char<-df_char[!is.na(df_char$brand),]
df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char<-df_char[(df_char$timeq>'2008 Q4')&(df_char$timeq<='2016 Q3'),]
df_char$lncost<-log(df_char$cost)

tlist<-c('2012 Q2','2013 Q2','2014 Q2')
count=1
  for (t in tlist){

    df_nomiss<-completeFun(df_char,c('lncost','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses','rdint','dpat'))
    
    counts <- data.frame(table(df_nomiss$panel))
    nonmissing<-counts[counts$Freq>=18,]
    df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]
    
    df_synth$pm<-ifelse(df_synth$timeq>=t,1,0)
    df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
    df_synth$pmtreat<-df_synth$pm * df_synth$treat
    
    panelView(lncost ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 
    
    #panelView(rdint ~ pmtreat, data = synth_data,  index = c("panel","timeq"), type = "raw") 
    
    model <- gsynth(lncost~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt+rdint+dpat, data = df_synth,
                    index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                    inference = "parametric", r = c(0, 5), CV = TRUE, 
                    force = "unit", nboots = 1000, seed = 1111, parallel = TRUE)
    
    
    att=signif(model$est.avg[1],3)
    se=signif(model$est.avg[2],3)
    att=ifelse(abs(att/se)>2.576,paste0(att,'***'),ifelse((abs(att/se)<=2.576)&(abs(att/se)>1.960),paste0(att,'**'),
                                                          ifelse((abs(att/se)<=1.960)&(abs(att/se)>1.645),paste0(att,'*'),att)))
    assign(paste0('pcostatt',count),att)
    assign(paste0('pcostse',count),se)
    control=as.integer(model$Nco)
    assign(paste0('pcostcontrol',count),control)
    mspe=signif(model$MSPE,3)
    assign(paste0('pcostmspe',count),mspe)
    
    count=count+1
  }


bracket<-function(x){
  x<-paste0('(',x,')')
}


row1<-cbind(rdatt20011,patatt20011,numatt20011,costatt20011)
row2<-cbind(rdse20011,patse20011,numse20011,costse20011)
row3<-cbind(rdmspe20011,patmspe20011,nummspe20011,costmspe20011)
row4<-cbind(rdatt20021,patatt20021,numatt20021,costatt20021)
row5<-cbind(rdse20021,patse20021,numse20021,costse20021)
row6<-cbind(rdmspe20021,patmspe20021,nummspe20021,costmspe20021)
row7<-cbind(rdatt20031,patatt20031,numatt20031,costatt20031)
row8<-cbind(rdse20031,patse20031,numse20031,costse20031)
row9<-cbind(rdmspe20031,patmspe20031,nummspe20031,costmspe20031)
row10<-cbind(prdatt1,ppatatt1,pnumatt1,pcostatt1)
row11<-cbind(prdse1,ppatse1,pnumse1,pcostse1)
row12<-cbind(prdmspe1,ppatmspe1,pnummspe20031,pcostmspe1)

first<-rbind(row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12)

for(row in c(2,5,8,11)){first[row,] <- sapply(first[row,], function(x) bracket(x))}
row.names(first)<-c('Seagate','sd','MSPE','WD','WD sd','WD MSPE','Toshiba','TO sd','TO MSPE','Pooled','pooled sd','Pooled MSPE')


row1<-cbind(rdatt20012,patatt20012,numatt20012,costatt20012)
row2<-cbind(rdse20012,patse20012,numse20012,costse20012)
row3<-cbind(rdmspe20012,patmspe20012,nummspe20012,costmspe20012)
row4<-cbind(rdatt20022,patatt20022,numatt20022,costatt20022)
row5<-cbind(rdse20022,patse20022,numse20022,costse20022)
row6<-cbind(rdmspe20022,patmspe20022,nummspe20022,costmspe20022)
row7<-cbind(rdatt20032,patatt20032,numatt20032,costatt20032)
row8<-cbind(rdse20032,patse20032,numse20032,costse20032)
row9<-cbind(rdmspe20032,patmspe20032,nummspe20032,costmspe20032)
row10<-cbind(prdatt2,ppatatt2,pnumatt2,pcostatt2)
row11<-cbind(prdse2,ppatse2,pnumse2,pcostse2)
row12<-cbind(prdmspe2,ppatmspe2,pnummspe2,pcostmspe2)

second<-rbind(row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12)

for(row in c(2,5,8,11)){second[row,] <- sapply(second[row,], function(x) bracket(x))}
row.names(second)<-c('Seagate','sd','MSPE','WD','WD sd','WD MSPE','Toshiba','TO sd','TO MSPE','Pooled','pooled sd','Pooled MSPE')


row1<-cbind(rdatt20013,patatt20013,numatt20013,costatt20013)
row2<-cbind(rdse20013,patse20013,numse20013,costse20013)
row3<-cbind(rdmspe20013,patmspe20013,nummspe20013,costmspe20013)
row4<-cbind(rdatt20023,patatt20023,numatt20023,costatt20023)
row5<-cbind(rdse20023,patse20023,numse20023,costse20023)
row6<-cbind(rdmspe20023,patmspe20023,nummspe20023,costmspe20023)
row7<-cbind(rdatt20033,patatt20033,numatt20033,costatt20033)
row8<-cbind(rdse20033,patse20033,numse20033,costse20033)
row9<-cbind(rdmspe20033,patmspe20033,nummspe20033,costmspe20033)
row10<-cbind(prdatt3,ppatatt3,pnumatt3,pcostatt3)
row11<-cbind(prdse3,ppatse3,pnumse3,pcostse3)
row12<-cbind(prdmspe3,ppatmspe3,pnummspe3,pcostmspe3)

third<-rbind(row1,row2,row3,row4,row5,row6,row7,row8,row9,row10,row11,row12)

for(row in c(2,5,8,11)){third[row,] <- sapply(third[row,], function(x) bracket(x))}
row.names(third)<-c('Seagate','sd','MSPE','WD','WD sd','WD MSPE','Toshiba','TO sd','TO MSPE','Pooled','pooled sd','Pooled MSPE')
controls<-cbind(rdcontrol20011,patcontrol20011,numcontrol20011,costcontrol20011)

result<-as.data.frame(rbind(first, second, third,controls))


colnames(result)<-c('R&D Int','Patent count','Number of new models','Unit cost')



write.xlsx(result,'gsynth_results2_.xlsx')
