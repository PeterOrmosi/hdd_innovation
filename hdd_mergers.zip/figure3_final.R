
library(zoo)
library(gsynth)
library(dplyr)
library(Synth)
require(Rcpp)
require(ggplot2)
require(GGally) 
require(foreach)  
require(doParallel) 
require(abind)
library(panelView)
library(ggpubr)
library(panelView)
library(tidyverse)

completeFun <- function(data, desiredCols) {
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
}


theme_set(theme_bw(base_size = 18))

My_Theme = theme(
  axis.title.x = element_text(size = 18),
  axis.text.x = element_text(size = 11),
  axis.title.y = element_text(size = 18),
  axis.text.y = element_text(size = 11))



gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char$timeq<-as.yearqtr(df_char$timeq)

df_char$num_cum<-as.numeric(ave(df_char$number, df_char$panel, FUN=cumsum))

df_char<-df_char[(df_char$timeq>'2006 Q4')&(df_char$timeq<='2016 Q2'),]

df_nomiss<-completeFun(df_char,c('rdint','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))

counts <- data.frame(table(df_nomiss$panel))
nonmissing<-counts[counts$Freq>=37,]
df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]

df_synth <- df_synth %>% filter((panel<2000)|(panel==2001)|(panel==2002)) # selecting Seagate

df_synth$pm<-ifelse(df_synth$timeq>="2013 Q2",1,0)
df_synth$treat<-ifelse((df_synth$panel>2000),1,0)

df_synth$pmtreat<-df_synth$pm * df_synth$treat

panelView(rdint ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 


model <- gsynth(rdint~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt, data = df_synth,
                index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                inference = "parametric", r = c(0, 5), CV = TRUE, 
                force = "unit", nboots = 1000, seed = 1234,parallel = TRUE)


att1=paste("ATT = ",as.character(signif(model$est.avg[1],3)))
se1=paste("std.err. = ", as.character(signif(model$est.avg[2],3)))
control1=paste("Number of control firms: ",as.character((model$Nco)))
sub1 = paste(att1,", ",se1,"\n",control1)
fig<-plot(model,  raw = "none",main="",axis.adjust=TRUE,xlab=sub1) + geom_hline(yintercept = 0,color="black", linetype=4) +
  geom_vline(xintercept = 0,color="black", linetype=4) +
  scale_x_continuous(breaks = c(-20,-10,0,10),labels=c('Q1 2008','Q3 2010','Q1 2013','Q3 2015')) + My_Theme
fig1<-annotate_figure(fig,top = text_grob("R&D Intensity", face = "bold", size = 18)) 






### DPAT
gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100
df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$num_cum<-as.numeric(ave(df_char$number, df_char$panel, FUN=cumsum))
df_char<-df_char[(df_char$timeq>'2006 Q4')&(df_char$timeq<='2016 Q2'),]

df_nomiss<-completeFun(df_char,c('dpat','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))

counts <- data.frame(table(df_nomiss$panel))
df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]


df_synth$pm<-ifelse(df_synth$timeq>="2013 Q2",1,0)
df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
df_synth$pmtreat<-df_synth$pm * df_synth$treat

panelView(dpat ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 

model <- gsynth(dpat~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt, data = df_synth,
                index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                inference = "parametric", r = c(0, 5), CV = TRUE, 
                force = "unit", nboots = 1000, seed = 1234,parallel = TRUE)


att2=paste("ATT = ",as.character(signif(model$est.avg[1],3)))
se2=paste("std.err. = ", as.character(signif(model$est.avg[2],3)))
control2=paste("Number of control firms: ",as.character((model$Nco)))
sub2 = paste(att2,", ",se2,"\n",control2)
fig<-plot(model,  raw = "none",main="",axis.adjust=TRUE,xlab=sub2) + geom_hline(yintercept = 0,color="black", linetype=4) +
  geom_vline(xintercept = 0,color="black", linetype=4) +
  scale_x_continuous(breaks = c(-20,-10,0,10),labels=c('Q1 2008','Q3 2010','Q1 2013','Q3 2015')) + My_Theme
fig2<-annotate_figure(fig,top = text_grob("Number of new patents", face = "bold", size = 18))




### NUMBER
gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$num_cum<-as.numeric(ave(df_char$number, df_char$panel, FUN=cumsum))
df_char<-df_char[(df_char$timeq>'2008 Q4')&(df_char$timeq<='2016 Q3'),]

  
df_nomiss<-completeFun(df_char,c('number','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses','rdint','dpat'))

counts <- data.frame(table(df_nomiss$panel))
nonmissing<-counts[counts$Freq>=18,]
df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]


df_synth$pm<-ifelse(df_synth$timeq>="2013 Q2",1,0)
df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
df_synth$pmtreat<-df_synth$pm * df_synth$treat

panelView(number ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 

model <- gsynth(number~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt+rdint+dpat, data = df_synth,
                index = c("panel","timeq"),  inference = "parametric",se = TRUE, estimator="mc",
                force = "unit", nboots = 1000, seed = 1234, parallel = TRUE)


att3=paste("ATT = ",as.character(signif(model$est.avg[1],3)))
se3=paste("std.err. = ", as.character(signif(model$est.avg[2],3)))
control3=paste("Number of control firms: ",as.character((model$Nco)))
sub3 = paste(att3,", ",se3,"\n",control3)
fig<-plot(model, raw = "none",main="",axis.adjust=TRUE,xlab=sub3) + geom_hline(yintercept = 0,color="black", linetype=4) +
  geom_vline(xintercept = 0,color="black", linetype=4) +
  scale_x_continuous(breaks = c(-20,-10,0,10),labels=c('Q1 2008','Q3 2010','Q1 2013','Q3 2015')) + My_Theme
fig3<-annotate_figure(fig,top = text_grob("Number of new models", face = "bold", size = 18))



## COST
gc()

setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")
df_char$rdint<-df_char$rdint*100

df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$num_cum<-as.numeric(ave(df_char$number, df_char$panel, FUN=cumsum))
df_char<-df_char[(df_char$timeq>'2008 Q4')&(df_char$timeq<='2016 Q3'),]
df_char$lncost<-log(df_char$cost)

df_nomiss<-completeFun(df_char,c('lncost','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses','rdint','dpat'))

counts <- data.frame(table(df_nomiss$panel))
nonmissing<-counts[counts$Freq>=18,]
df_synth <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]

df_synth$pm<-ifelse(df_synth$timeq>="2013 Q2",1,0)
df_synth$treat<-ifelse(df_synth$panel>2000,1,0)
df_synth$pmtreat<-df_synth$pm * df_synth$treat

panelView(lncost ~ pmtreat, data = df_synth,  index = c("panel","timeq"),axis.adjust=TRUE) 

model <- gsynth(lncost~ pmtreat+totalrevenue+grossprofit+netincome+expenses+totalassets+totaldebt+rdint+dpat, data = df_synth,
                index = c("panel","timeq"),  se = TRUE, estimator="mc", 
                inference = "parametric", r = c(0, 5), CV = TRUE, 
                force = "unit", nboots = 1000, seed = 1234, parallel = TRUE)

att4=paste("ATT = ",as.character(signif(model$est.avg[1],3)))
se4=paste("std.err. = ", as.character(signif(model$est.avg[2],3)))
control4=paste("Number of control firms: ",as.character((model$Nco)))
sub4 = paste(att4,", ",se4,"\n",control4)
fig<-plot(model, raw = "none",main="",axis.adjust=TRUE,xlab=sub4) + geom_hline(yintercept = 0,color="black", linetype=4) +
  geom_vline(xintercept = 0,color="black", linetype=4) +
  scale_x_continuous(breaks = c(-20,-10,0,10),labels=c('Q1 2008','Q3 2010','Q1 2013','Q3 2015')) + My_Theme
fig4<-annotate_figure(fig,top = text_grob("Unit price (log)", face = "bold", size = 18))



figure<-ggarrange(fig1,fig3,fig2,fig4,ncol = 2, nrow = 2)


ggsave('att_pooled2013.pdf',plot=figure,dpi = 700,scale=2)


