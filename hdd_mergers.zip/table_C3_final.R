# install.packages('gsynth')
# install.packages('plm')
# install.packages('panelview')
# install.packages('dlnm')
# install.packages('ggpubr')
# install.packages('multcomp')
# install.packages('panelView')
# install.packages('xlsx')

library(zoo)
library(gsynth)
library(dplyr)
library(Synth)
require(Rcpp)
require(ggplot2)
require(GGally) 
require(foreach)  
require(doParallel) 
require(abind)
library(panelView)
library(ggpubr)
library(panelView)
library(tidyverse)
library(plm)
library(multcomp)
library(dlnm)
library(foreign)
library(data.table)
library(lmtest)
library(xlsx)
library(lubridate)

completeFun <- function(data, desiredCols) {
  completeVec <- complete.cases(data[, desiredCols])
  return(data[completeVec, ])
}

bracket<-function(x){
  x<-paste0('(',x,')')
}

starring<-function(x){
  coef1=round(x[1],3)
  est=ifelse(x[4]<0.01,paste0(coef1,'***'),ifelse((x[4]>=0.01)&(x[4]<0.05),paste0(coef1,'**'),
                                                  ifelse((x[4]>=0.05)&(x[4]<0.1),paste0(coef1,'*'),coef1))) 
  
}

starringse<-function(x){
  serr=paste0("(",round(x[2],4),")")
}




setwd("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/synth") # UEA


df_char<-read.csv("c:/Users/peter/OneDrive - University of East Anglia/UEA/Consultancies/EC/Innovation/data/characteristics/new/2020/char_data2020all.csv")


df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$number[is.na(df_char$number)]<-0
df_char$lncost<-log(df_char$cost)
df_char<-df_char[(df_char$timeq>'2006 Q4')&(df_char$timeq<='2016 Q2'),]
#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]
df_nomiss<-completeFun(df_char,c('rdint','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))

counts <- data.frame(table(df_nomiss$panel))
nonmissing<-counts[counts$Freq>=37,]
df_char <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]

df_char$panel2<-df_char$panel
df_char$rdint<-df_char$rdint*100
df_char<-pdata.frame(df_char,index=c("panel2","timeq"))  
df_char$rdint4 <-lag(df_char$rdint,4)
df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$t<-as.numeric(df_char$timeq)

#write.csv(df_char,'data_with_weights.csv')




# REGRESSIONS


## SEAGATE

#fnum <- as.formula(paste('number', paste(c('pm','pmtreat','lag(rdint,4)','lag(rdint,4):pmtreat','lag(dpat,2)','lag(dpat,2):pmtreat'),
#                                      collapse = " + "),sep = " ~ "))
#fcost <- as.formula(paste('lncost', paste(c('pm','pmtreat','lag(rdint,4)','lag(rdint,4):pmtreat','lag(dpat,2)','lag(dpat,2):pmtreat'),
#                                         collapse = " + "),sep = " ~ "))
vars<-c('pm','pmtreat','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses')
vars2<-c('pm','pmtreat','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses','rdint4')
varst<-c('treat','t','treat:t','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses')
varst2<-c('treat','t','treat:t','totalrevenue','grossprofit','totalassets','netincome','totaldebt','rdint4')
frd <- as.formula(paste('rdint', paste(vars, collapse = " + "),sep = " ~ "))
frdt <- as.formula(paste('rdint', paste(varst, collapse = " + "),sep = " ~ "))

fpat <- as.formula(paste('dpat', paste(vars, collapse = " + "),sep = " ~ "))
fpatt <- as.formula(paste('dpat', paste(varst, collapse = " + "),sep = " ~ "))

fnum <- as.formula(paste('number', paste(vars2, collapse = " + "),sep = " ~ "))
fnumt <- as.formula(paste('number', paste(varst2, collapse = " + "),sep = " ~ "))

fcost <- as.formula(paste('lncost', paste(vars2, collapse = " + "),sep = " ~ "))
fcostt <- as.formula(paste('lncost', paste(varst2, collapse = " + "),sep = " ~ "))

#fnum <- as.formula(paste('number', paste(c('pm','pmtreat','lag(dpat,2)','lag(dpat,2):pmtreat'),
#                                         collapse = " + "),sep = " ~ "))
#fcost <- as.formula(paste('lncost', paste(c('pm','pmtreat','lag(dpat,2)','lag(dpat,2):pmtreat'),
#                                          collapse = " + "),sep = " ~ "))

deps<-c('frd','fpat')
depst<-c('frdt','fpatt')
firms<-c(2001,2002,2003)
tlist<-c('2012 Q2','2013 Q2','2014 Q1')

for (d in 1:length(deps)){
for (f in 1:length(firms)){
for (i in 1:length(tlist)){
  df<-df_char
  dft<-df_char[(df_char$timeq>'2006 Q4')&&(df_char$timeq<=as.yearqtr(tlist[i])),]
  df$treat<-ifelse(df$panel>2000,1,0)
  dft$treat<-ifelse(df$panel>2000,1,0)
  df$pm<-ifelse(df$timeq>=tlist[i],1,0)
  df <- df %>% filter((panel<2000)|(panel==firms[f]))
  dft <- dft %>% filter((panel<2000)|(panel==firms[f])) 
  df$pmtreat<-df$pm * df$treat
  number = plm(eval(deps[d]), data = df, index = c("panel", "timeq"), model = "within", effect='twoway')
  numbert = plm(eval(depst[d]), data = dft, index = c("panel", "timeq"), model = "within", effect='twoway')
  
  coef<-coeftest(number, vcov=vcovHC(number,type="HC0"))
  coeft<-coeftest(numbert) # , vcov=vcovHC(numbert,type="HC0"))
  
  size<-as.data.frame(t(as.factor(dim(number$model)[1])))
  names(size)<-c('pmtreat')
  table1<-(as.data.frame(apply(coef,1,starring)))
  table2<-(as.data.frame(apply(coef,1,starringse)))
  table=cbind(table1,table2)
  table <-as.data.frame( do.call(rbind, lapply(1:nrow(table), function(x) t(table[x,]))))
  colnames(size)=colnames(table)
  table<-rbind(table,size)
  table<-as.data.frame(table[c(1,2,15),])
  par<-as.data.frame(as.factor(round(coeft[7,4],4)))
  colnames(par)=colnames(table)
  table<-rbind(table,par)
  row.names(table)<-c('pmtreat','se','N','parallel p-val')

  assign(paste0('est',d,f,i),table)
}}}




df_char<-read.csv('data_with_weights.csv')

df_char$timeq<-as.yearqtr(df_char$timeq)

#df_char<-df_char[(df_char$timeq<'2011 Q4')|(df_char$timeq>'2012 Q2'),]
#df_nomiss<-completeFun(df_char,c('brand','number','rdint','totalrevenue','grossprofit','totalassets','netincome','totaldebt','expenses'))

#counts <- data.frame(table(df_nomiss$panel))
#nonmissing<-counts[counts$Freq>=18,]
#df_char <-df_nomiss[df_nomiss$panel %in% nonmissing$Var1, ]

df_char$panel2<-df_char$panel
df_char$rdint<-df_char$rdint*100
df_char<-pdata.frame(df_char,index=c("panel2","timeq"))  
df_char$rdint4 <-lag(df_char$rdint,4)
df_char$timeq<-as.yearqtr(df_char$timeq)
df_char$t<-as.numeric(df_char$timeq)


deps<-c('fnum','fcost')
depst<-c('fnumt','fcostt')

firms<-c(2001,2002,2003)
tlist<-c('2012 Q2','2013 Q2','2014 Q2')

for (d in 1:length(deps)){
  for (f in 1:length(firms)){
    for (i in 1:length(tlist)){
      df<-df_char[(df_char$timeq>='2010 Q3')&(df_char$timeq<='2016 Q3'),]
      dft<-df_char[(df_char$timeq>='2010 Q3')&(df_char$timeq<=as.yearqtr(tlist[i])),]
      df$treat<-ifelse(df$panel>2000,1,0)
      dft$treat<-ifelse(dft$panel>2000,1,0)
      df$pm<-ifelse(df$timeq>=tlist[i],1,0)
      df <- df %>% filter((panel<2000)|(panel==firms[f]))
      dft <- dft %>% filter((panel<2000)|(panel==firms[f])) 
      df$pmtreat<-df$pm * df$treat
      number = plm(eval(deps[d]), data = df, index = c("panel", "timeq"), model = "within", effect='individual')
      numbert = plm(eval(depst[d]), data = dft, index = c("panel", "timeq"), model = "within", effect='individual')
      
      coef<-coeftest(number, vcov=vcovHC(number,type="HC0"))
      coeft<-coeftest(numbert) #, vcov=vcovHC(numbert,type="HC0"))
      
      size<-as.data.frame(t(as.factor(dim(number$model)[1])))
      names(size)<-c('pmtreat')
      table1<-(as.data.frame(apply(coef,1,starring)))
      table2<-(as.data.frame(apply(coef,1,starringse)))
      table=cbind(table1,table2)
      table <-as.data.frame( do.call(rbind, lapply(1:nrow(table), function(x) t(table[x,]))))
      colnames(size)=colnames(table)
      table<-rbind(table,size)
      table<-as.data.frame(table[c(1,2,19),])
      par<-as.data.frame(as.factor(round(coeft[8,4],4)))
      colnames(par)=colnames(table)
      table<-rbind(table,par)
      row.names(table)<-c('pmtreat','se','N','parallel p-val')

      assign(paste0('est_',d,f,i),table)
    }}}






tab1<-cbind(est111,est211,est_111,est_211)
tab2<-cbind(est121,est221,est_121,est_221)
tab3<-cbind(est131,est231,est_131,est_231)

tab4<-cbind(est112,est212,est_112,est_212)
tab5<-cbind(est122,est222,est_122,est_222)
tab6<-cbind(est132,est232,est_132,est_232)

tab7<-cbind(est113,est213,est_113,est_213)
tab8<-cbind(est123,est223,est_123,est_223)
tab9<-cbind(est133,est233,est_133,est_233)


table<-rbind(tab1,tab2,tab3,tab4,tab5,tab6,tab7,tab8,tab9)




colnames(table)<-c('R&D Int','Patent count','Number of new models','Unit cost')
write.xlsx(table,'table_3_ols.xlsx')
#write.xlsx(table,'table_pat_weighted_4_2.xlsx')

